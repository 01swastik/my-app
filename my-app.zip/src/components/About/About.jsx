import './About.css'

export default function About(){


    return(
        <>
          <center><h1>About Us</h1>
          <p>Web developers are responsible for programming the code that 'tells' a website how to function. They build websites that are 'user friendly', which means they are easy to navigate for those using them. They also build functions within a website — for example, a form to capture an e-mail or to provide a newsletter, a paywall to capture payment details, or a message to thank a customer for their business.</p>
          </center>
        </>
    )
}