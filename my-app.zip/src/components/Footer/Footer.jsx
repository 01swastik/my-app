import './Footer.css';

export default function Footer(){
    return(
        <div className="footer">
        <p> made with ❤️ by Prathmesh Sawant</p>
        </div>
    )
}