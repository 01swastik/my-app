import './Home.css'

export default function Home(){
  
    return(
      <div id="Home">
      <img src="https://tse3.mm.bing.net/th?id=OIP.pRYMY3J-PAbMDKQRg7gEeQHaD4&pid=Api&P=0"></img>
      </div>
    )
}